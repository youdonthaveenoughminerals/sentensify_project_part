import json
import pandas as pd
import os
import re

# 1. 설정 변수
# 파일 경로 (Raw String 또는 슬래시 사용)
json_file_path = 'C:/Users/user/Downloads/data_북엔드(추가)/추가제공데이터/문장교정기록.json'
# 저장할 클리닝된 CSV 파일명
output_csv_path = 'cleaned_f2_corpus.csv'

# [수정 필요] JSON 진단 결과에 따라 키 이름 수정
# 텍스트 키: 'input_sentence'로 확정
text_column_name = 'input_sentence'
# 레이블 키: 'operation_type'이 가장 유력하지만, 필요한 분류 목적에 따라 'tone' 등으로 변경 가능
label_column_name = 'operation_type' 

def correct_encoding_issue(text):
    """
    텍스트 클리닝 함수입니다.
    """
    if isinstance(text, str):
        text = text.replace('\n', ' ').strip()
        text = re.sub(r'\s+', ' ', text)
        return text
    return ""

def process_data(json_path, output_path, text_key, label_key):
    """
    JSON 파일에서 텍스트와 레이블을 추출하고 클리닝하여 CSV로 저장합니다.
    """
    # 윈도우 환경에서 콘솔 인코딩 오류 방지를 위한 설정 (필수는 아니지만 안정성 향상)
    import sys
    if sys.platform.startswith('win'):
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except AttributeError:
            # Python 3.7 이하 버전에서는 reconfigure를 사용할 수 없습니다.
            pass

    print(f"[INFO] JSON 파일 로드 시작: {json_path}")
    
    if not os.path.exists(json_path):
        print(f"[FATAL ERROR] JSON 파일 경로를 찾을 수 없습니다: {json_path}")
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"[FATAL ERROR] JSON 파일 로드 중 오류 발생. 인코딩 확인 필요: {e}")
        return

    print("[INFO] JSON 데이터 로드 완료. 텍스트 및 레이블 추출 시작...")

    corpus = []
    data_list = data
    
    # 딕셔너리 내부에 실제 리스트가 있을 수 있는 구조 대응
    if isinstance(data, dict):
        for value in data.values():
            if isinstance(value, list):
                data_list = value
                break
        
    if not isinstance(data_list, list):
        print("[FATAL ERROR] JSON 파일 구조가 예상(리스트 형태)과 다릅니다.")
        return

    # 데이터 추출 루프
    for item in data_list:
        if isinstance(item, dict) and text_key in item and label_key in item:
            text = item[text_key]
            label = item[label_key]
            
            cleaned_text = correct_encoding_issue(text)
            
            corpus.append({
                'category': label,
                'original_text': cleaned_text
            })

    print(f"[INFO] 총 {len(corpus)}개의 유효한 데이터 항목 추출 완료.")

    if not corpus:
        print("[FATAL ERROR] 추출된 데이터가 0개입니다. 키 이름을 확인해 주세요.")
        if data_list and isinstance(data_list[0], dict):
            print(f"--- 진단 결과 ---")
            print(f"[DIAGNOSTIC] 첫 번째 데이터 항목의 사용 가능한 키 목록:")
            print(f"  {list(data_list[0].keys())}")
            print(f"  현재 설정된 텍스트 키: '{text_key}'")
            print(f"  현재 설정된 레이블 키: '{label_key}'")
            print("---")
            print(f"**해결책**: 위에 출력된 '사용 가능한 키 목록'을 보고, 텍스트와 레이블 키를 정확하게 수정하세요.")
        return

    # DataFrame 생성 및 CSV 저장
    df = pd.DataFrame(corpus)
    df.dropna(subset=['category', 'original_text'], inplace=True)
    df.to_csv(output_path, index=False, encoding='utf-8')
    
    print(f"--- 데이터 처리 완료 ---")
    print(f"[SUCCESS] 클리닝된 데이터가 {output_path}에 저장되었습니다.")
    print(f"[INFO] 저장된 DataFrame 컬럼: {df.columns.tolist()}")
    print(f"[INFO] 최종 데이터 크기: {len(df)} 행")

# 메인 실행 함수
if __name__ == "__main__":
    process_data(json_file_path, output_csv_path, text_column_name, label_column_name)