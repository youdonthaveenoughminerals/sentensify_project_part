import asyncio
import httpx # 비동기 HTTP 요청을 위한 라이브러리
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import json

# --- 1. 환경 설정 및 상수 (실제 배포 시 환경 변수 사용 권장) ---
API_KEY = "" # 실제로는 __api_key__ 또는 환경 변수로 설정
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key={API_KEY}"
# 1단계에서 구축할 ONNX 서버의 내부 엔드포인트 주소
ONNX_SERVER_URL = "http://localhost:8001/predict" 
CONFIDENCE_THRESHOLD = 0.85 # Gemini가 개입할 확신도 임계값

app = FastAPI(title="Sentensify Hybrid Correction Service")
client = httpx.AsyncClient(timeout=10.0) # 비동기 클라이언트 초기화 (타임아웃 10초)

# --- 2. 요청 및 응답 데이터 구조 ---
class CorrectionRequest(BaseModel):
    """사용자 요청 데이터 모델"""
    text: str # 교정할 원문
    user_id: str # 개인화 데이터를 가져올 사용자 ID

class CorrectionResponse(BaseModel):
    """최종 응답 데이터 모델"""
    original_text: str
    corrected_text: str
    model_used: str # ONNX 또는 Gemini
    inference_time_ms: float # 총 추론 소요 시간 (ms)

# --- 3. Mock/Utility 함수 (실제로는 Firestore/ONNX 서버 통신) ---

async def fetch_user_context(user_id: str):
    """
    [MOCK] Firestore 등에서 사용자 누적 데이터 및 개인화 맥락을 비동기로 조회합니다.
    """
    # 실제로는 await getDoc(doc(db, "users", user_id)) 형태가 될 것
    await asyncio.sleep(0.005) # 5ms 지연 시뮬레이션
    return {
        "user_id": user_id,
        "domain": "전문 금융 보고서 작성",
        "recent_topics": ["AI 투자 전략", "주식시장 IPO"],
        "preferred_tone": "객관적, 분석적",
    }

async def call_onnx_server(text: str):
    """
    [MOCK] 1단계에서 구축된 ONNX 고속 서빙 엔드포인트에 요청을 보냅니다.
    """
    # 실제 ONNX 서버 호출 (ONNX_SERVER_URL 사용)
    # Mocking Team B's failure for complex sentences to trigger Gemini
    text_length = len(text)
    
    # 3ms 이내의 속도를 시뮬레이션
    await asyncio.sleep(0.003) 
    
    # 길이가 길면 확신도가 떨어지도록 시뮬레이션
    confidence = 0.95 - (min(text_length, 200) / 400) * 0.2 
    
    if confidence < CONFIDENCE_THRESHOLD:
        return {
            "corrected_text": "ONNX 1차 교정 실패 (문법 오류 수정만)",
            "confidence": confidence,
            "time_ms": 3.0
        }
    else:
        return {
            "corrected_text": f"ONNX 고속 교정 완료: {text[:20]}...",
            "confidence": confidence,
            "time_ms": 3.0
        }

async def call_gemini_api(original_text: str, user_context_data: dict):
    """
    Gemini API를 호출하여 맥락 기반 심층 교정 및 개인화를 수행합니다.
    """
    system_prompt = f"""
    당신은 Sentensify의 고급 문장 완성 및 교정 시스템입니다. 
    1. 사용자의 과거 데이터({json.dumps(user_context_data, ensure_ascii=False)})를 분석하여 사용자의 도메인({user_context_data['domain']})과 선호하는 어조({user_context_data['preferred_tone']})를 파악하세요.
    2. 사용자 문장을 문법적 오류를 넘어, 맥락적으로 가장 자연스럽고 설득력 있게 완성/교정하세요.
    3. 원문보다 더 나은 '고급 문장' 하나만 반환하세요. 응답에는 교정된 문장 외 다른 설명이나 부연설명을 포함하지 마세요.
    """
    user_query = f"다음 문장을 교정 및 완성하세요: '{original_text}'"

    payload = {
        "contents": [{"parts": [{"text": user_query}]}],
        "systemInstruction": {"parts": [{"text": system_prompt}]},
    }
    
    try:
        # 비동기적으로 Gemini API 호출
        response = await client.post(GEMINI_API_URL, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        # 텍스트 추출 로직
        text = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', 'Gemini 응답 추출 실패')
        
        return text, response.elapsed.total_seconds() * 1000 # 응답 시간 반환
    
    except httpx.HTTPStatusError as e:
        print(f"Gemini API Error: {e.response.text}")
        raise HTTPException(status_code=500, detail="Gemini API 호출 중 오류 발생")
    except Exception as e:
        print(f"General API Error: {e}")
        raise HTTPException(status_code=500, detail="알 수 없는 API 오류 발생")


# --- 4. 메인 하이브리드 컨트롤러 엔드포인트 ---

@app.post("/correct", response_model=CorrectionResponse)
async def hybrid_correction(request: CorrectionRequest):
    """
    ONNX로 고속 추론을 시도하고, 확신도가 낮을 경우 Gemini로 폴백하여 심층 교정을 수행합니다.
    """
    start_time = asyncio.get_event_loop().time()

    # 1. ONNX (1차 고속 추론) 실행
    onnx_data = await call_onnx_server(request.text)
    
    onnx_confidence = onnx_data["confidence"]
    final_result = onnx_data["corrected_text"]
    final_model = "ONNX"
    
    total_onnx_time = onnx_data["time_ms"]
    
    # 2. 확신도 기반 Gemini 개입 결정 (폴백 로직)
    if onnx_confidence < CONFIDENCE_THRESHOLD:
        
        # 2-1. 개인화 데이터 비동기 조회
        user_context = await fetch_user_context(request.user_id)
        
        # 2-2. Gemini (2차 심층 교정) 실행
        gemini_correction, gemini_time = await call_gemini_api(request.text, user_context)
        
        final_result = gemini_correction
        final_model = "Gemini"
        
        print(f"[LOG] Gemini 개입: ONNX {onnx_confidence:.4f} < {CONFIDENCE_THRESHOLD:.2f}. Gemini 소요 시간: {gemini_time:.2f}ms")
    else:
        print(f"[LOG] ONNX 고속 처리: 확신도 {onnx_confidence:.4f} >= {CONFIDENCE_THRESHOLD:.2f}.")

    end_time = asyncio.get_event_loop().time()
    total_elapsed_ms = (end_time - start_time) * 1000
    
    return CorrectionResponse(
        original_text=request.text,
        corrected_text=final_result,
        model_used=final_model,
        inference_time_ms=total_elapsed_ms
    )

# FastAPI 실행 예시 (Uvicorn 사용):
# uvicorn hybrid_correction_service:app --reload --port 8000
#
# 테스트 요청 예시 (Gemini 미개입):
# curl -X POST http://localhost:8000/correct -H "Content-Type: application/json" -d '{"text": "안녕하세요. 오늘 날씨가 아주 좋네요.", "user_id": "test_user"}'
#
# 테스트 요청 예시 (Gemini 개입 - 긴 문장):
# curl -X POST http://localhost:8000/correct -H "Content-Type: application/json" -d '{"text": "AI 스타트업 업스테이지가 기업공개(IPO)에 나섰다. 아마존, AMD 등 글로벌 빅테크로부터 투자를 유치하면서 선도적인 기술력을 입증한 만큼 시장의 기대감도 크다. 국내 증시에서도 AI 열풍이 이어지고 있고 최근 상장한 AI 기업도 흥행에 성공한 가운데 업스테이지가 시장에 활기를 더할 전망이다. 이로 인해 한국 기술 시장의 미래에 대한 낙관론이 확산되고 있다.", "user_id": "test_user"}'