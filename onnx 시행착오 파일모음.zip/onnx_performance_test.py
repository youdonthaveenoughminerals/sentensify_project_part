import torch
import torch.nn as nn
import onnxruntime
import numpy as np
import time
import os

# =================================================================
# [⭐ 윈도우 환경 인코딩 오류 해결 코드]
# VS Code나 Windows 콘솔에서 'cp949' 인코딩 충돌을 방지하기 위해
# 강제로 출력 인코딩을 UTF-8로 설정합니다.
import io
import sys
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
# =================================================================


# --- 1. 모의 PyTorch 추천 모델 정의 (시뮬레이션) ---
# 이 모델은 실제 프로젝트의 지도 학습 추천 모델을 시뮬레이션합니다.
class SimpleRecommendationModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleRecommendationModel, self).__init__()
        self.layer1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = self.layer1(x)
        x = self.relu(x)
        x = self.layer2(x)
        return x

# 모델 설정
INPUT_SIZE = 512    # 임베딩 차원 (예: Q13 임베딩 크기)
HIDDEN_SIZE = 128
OUTPUT_SIZE = 1     # 추천 점수 (Score)
MODEL_PATH = "recommendation_model.onnx"
NUM_RUNS = 1000     # 성능 측정 반복 횟수

# 더미 입력 데이터 준비 (실제 사용자 입력 데이터 시뮬레이션)
# 배치 크기 1, 임베딩 크기 512
dummy_input = torch.randn(1, INPUT_SIZE)

# 모델 인스턴스 생성 및 가중치 저장 (학습 완료 시뮬레이션)
torch_model = SimpleRecommendationModel(INPUT_SIZE, HIDDEN_SIZE, OUTPUT_SIZE)
torch_model.eval() # 추론 모드 설정

print(f"--- 1단계: PyTorch 모델 정의 완료 (입력 크기: {INPUT_SIZE}) ---")


# --- 2. PyTorch 모델을 ONNX 포맷으로 변환 및 저장 ---
try:
    # ONNX로 export
    # NOTE: PyTorch가 ONNX 18 버전을 권장하여 경고가 발생할 수 있으나, 변환 자체는 문제 없이 진행됩니다.
    torch.onnx.export(
        torch_model,               # 실행될 모델
        dummy_input,               # 모델 입력 (형태 유추용)
        MODEL_PATH,                # 저장될 ONNX 파일 경로
        export_params=True,        # 학습된 가중치 포함 여부
        opset_version=17,          # ONNX 연산자 세트 버전
        do_constant_folding=True,  # 상수 폴딩 최적화
        input_names=['input'],     # 입력 노드 이름
        output_names=['output'],   # 출력 노드 이름
        dynamic_axes={'input' : {0 : 'batch_size'}, 'output' : {0 : 'batch_size'}} # 배치 크기를 가변적으로 설정
    )
    print(f"--- 2단계: ONNX 모델 변환 성공. 파일 저장 경로: {MODEL_PATH} ---")
except Exception as e:
    # PyTorch 내부에서 오류가 발생하면, 오류 메시지를 안전하게 출력합니다.
    print(f"ONNX 변환 중 오류 발생: {e}")
    exit()


# --- 3. ONNX Runtime을 사용하여 모델 로드 및 추론 준비 ---
try:
    ort_session = onnxruntime.InferenceSession(MODEL_PATH)
    # 입력 노드의 이름 가져오기
    ort_inputs = {ort_session.get_inputs()[0].name: dummy_input.cpu().numpy()}
    print("--- 3단계: ONNX Runtime 세션 로드 완료 ---")
except Exception as e:
    print(f"ONNX Runtime 로드 중 오류 발생: {e}")
    # 파일 정리
    if os.path.exists(MODEL_PATH):
        os.remove(MODEL_PATH)
    exit()


# --- 4. 성능 평가 (Latency 비교) ---

# A. PyTorch 모델 성능 측정
print(f"\n--- A. PyTorch 추론 성능 측정 ({NUM_RUNS}회 반복) ---")
torch_times = []
with torch.no_grad():
    # Warm-up (첫 실행 시 부하를 미리 줌)
    for _ in range(10):
        _ = torch_model(dummy_input)

    # Measurement
    for _ in range(NUM_RUNS):
        start_time = time.time()
        _ = torch_model(dummy_input)
        end_time = time.time()
        torch_times.append(end_time - start_time)

avg_torch_time_ms = np.mean(torch_times) * 1000
print(f"PyTorch 평균 추론 시간: {avg_torch_time_ms:.4f} ms")


# B. ONNX Runtime 성능 측정
print(f"\n--- B. ONNX Runtime 추론 성능 측정 ({NUM_RUNS}회 반복) ---")
ort_times = []
# Warm-up (첫 실행 시 부하를 미리 줌)
for _ in range(10):
    _ = ort_session.run(None, ort_inputs)

# Measurement
for _ in range(NUM_RUNS):
    start_time = time.time()
    _ = ort_session.run(None, ort_inputs)
    end_time = time.time()
    ort_times.append(end_time - start_time)

avg_ort_time_ms = np.mean(ort_times) * 1000
print(f"ONNX Runtime 평균 추론 시간: {avg_ort_time_ms:.4f} ms")


# 최종 결과 비교
print("\n==============================================")
print(f"PyTorch: {avg_torch_time_ms:.4f} ms")
print(f"ONNX RT: {avg_ort_time_ms:.4f} ms")

if avg_ort_time_ms < avg_torch_time_ms:
    performance_gain = ((avg_torch_time_ms - avg_ort_time_ms) / avg_torch_time_ms) * 100
    print(f"[성공] ONNX Runtime이 PyTorch 대비 약 {performance_gain:.2f}% 더 빠릅니다.")
else:
    print("[주의] 현재 설정에서는 ONNX Runtime의 성능 이점이 미미합니다. (더 큰 모델이나 GPU 환경에서 차이가 커집니다.)")
print("==============================================")


# 생성된 ONNX 파일 정리
try:
    os.remove(MODEL_PATH)
    print(f"\n정리 완료: {MODEL_PATH} 파일 삭제.")
except OSError as e:
    print(f"파일 정리 중 오류 발생: {e}")