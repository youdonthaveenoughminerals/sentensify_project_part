import pandas as pd
import time
import random
from typing import List, Dict, Any

# --- 상수 설정 ---
# 테스트할 문장의 수를 20개로 변경 (기존 10개)
SAMPLE_SIZE = 20 

# ONNX 변환 및 INT8 양자화가 성공했을 때의 목표 성능 (ms)
# Step 1: 형식 추론 (입력 문장 임베딩 생성)
TARGET_TIME_STEP1_MS = 3.0
# Step 2: 데이터 임베딩 로드 (Vector DB I/O Latency) - ONNX와 무관
FIXED_TIME_STEP2_MS = 7.0 
# Step 3: 교정 모델 추론 (최종 교정)
TARGET_TIME_STEP3_MS = 3.0

# 총 목표 시간 (15ms 이내)
TARGET_TOTAL_TIME_MS = TARGET_TIME_STEP1_MS + FIXED_TIME_STEP2_MS + TARGET_TIME_STEP3_MS

def load_data(filepath: str, sample_size: int) -> List[str]:
    """
    CSV 파일에서 문장 데이터를 로드하고 지정된 개수만큼 샘플링합니다.
    """
    try:
        # 파일 로드 시 'field' 컬럼이 두 번째 컬럼이라고 가정하고 첫 번째 컬럼(content)만 사용
        df = pd.read_csv(filepath)
        
        # 'content' 컬럼이 없으면 에러 처리
        if 'content' not in df.columns:
            print("❌ 오류: CSV 파일에 'content' 컬럼이 없습니다.")
            return []

        # 지정된 개수만큼 랜덤 샘플링
        if len(df) < sample_size:
            print(f"⚠️ 경고: 데이터 파일의 문장이 {len(df)}개로, 요청된 {sample_size}개보다 적습니다. 전체 데이터를 사용합니다.")
            sampled_sentences = df['content'].tolist()
        else:
            sampled_sentences = df['content'].sample(n=sample_size, random_state=42).tolist()
            
        print(f"✅ '{filepath}'에서 총 {len(sampled_sentences)}개의 문장을 불러왔습니다.")
        return sampled_sentences

    except FileNotFoundError:
        print(f"❌ 오류: '{filepath}' 파일을 찾을 수 없습니다.")
        return []
    except Exception as e:
        print(f"❌ 데이터 로드 중 예상치 못한 오류 발생: {e}")
        return []

def simulate_hybrid_correction(sentence: str) -> Dict[str, Any]:
    """
    하이브리드 교정 시스템의 세 단계 성능을 목표치에 기반하여 시뮬레이션합니다.
    """
    
    # 1. Step 1: 형식 추론 및 임베딩 생성 (ONNX 모델 추론)
    # 목표 시간 (3ms) 근처에서 무작위 시간 생성 (예: 2.8ms ~ 3.2ms)
    time_step1_ms = TARGET_TIME_STEP1_MS + (random.uniform(-0.2, 0.2))

    # 2. Step 2: 데이터 임베딩 로드 (DB I/O Latency)
    # 고정 시간 (7ms) 근처에서 무작위 시간 생성 (예: 6.8ms ~ 7.2ms)
    time_step2_ms = FIXED_TIME_STEP2_MS + (random.uniform(-0.2, 0.2))

    # 3. Step 3: 교정 모델 추론 (ONNX 모델 추론)
    # 목표 시간 (3ms) 근처에서 무작위 시간 생성 (예: 2.8ms ~ 3.2ms)
    time_step3_ms = TARGET_TIME_STEP3_MS + (random.uniform(-0.2, 0.2))

    # 최종 계산
    total_ms = time_step1_ms + time_step2_ms + time_step3_ms
    
    # 임의로 문서 형식 분류 (기사, 논문, 보고서 중 하나)
    inferred_type = random.choice(['기사', '논문', '보고서'])
    
    return {
        'char_count': len(sentence),
        'time_step1_ms': time_step1_ms,
        'time_step2_ms': time_step2_ms,
        'time_step3_ms': time_step3_ms,
        'total_ms': total_ms,
        'inferred_type': inferred_type
    }

def run_simulation(sentences: List[str]):
    """
    시뮬레이션을 실행하고 결과를 테이블 형태로 출력합니다.
    """
    results = []
    
    # 테이블 헤더 출력
    print("\n" + "="*84)
    print(f"| {'ONNX 목표 시간 시뮬레이션 결과':^82} |")
    print(f"| (Step 1: 목표 {TARGET_TIME_STEP1_MS:.1f}ms / Step 3: 목표 {TARGET_TIME_STEP3_MS:.1f}ms / 총 목표 {TARGET_TOTAL_TIME_MS:.1f}ms) |")
    print("="*84)
    print(
        f"| {'문장 번호':<5} | {'문자 수':<5} | {'형식 추론 (ms)':<12} | {'DB 로드 (ms)':<12} | {'교정 추론 (ms)':<12} | {'총 시간 (ms)':<12} | {'분류 결과':<8} |"
    )
    print("-" * 84)

    # 시뮬레이션 실행 및 결과 출력
    for i, sentence in enumerate(sentences):
        result = simulate_hybrid_correction(sentence)
        results.append(result)

        # ⚠️ 수정된 부분: 실수형 포맷 지정자 변경 (:.3f:<12 -> <12.3f)
        print(
            f"| {i+1:<5} | {result['char_count']:<5} | {result['time_step1_ms']:<12.3f} | {result['time_step2_ms']:<12.3f} | {result['time_step3_ms']:<12.3f} | {result['total_ms']:<12.3f} | {result['inferred_type']:<8} |"
        )

    print("-" * 84)

    # 요약 통계 계산
    avg_total_ms = sum(r['total_ms'] for r in results) / len(results) if results else 0
    avg_step1_ms = sum(r['time_step1_ms'] for r in results) / len(results) if results else 0
    avg_step2_ms = sum(r['time_step2_ms'] for r in results) / len(results) if results else 0
    avg_step3_ms = sum(r['time_step3_ms'] for r in results) / len(results) if results else 0

    print(
        f"| {'평균':<5} | {'':<5} | {avg_step1_ms:<12.3f} | {avg_step2_ms:<12.3f} | {avg_step3_ms:<12.3f} | {avg_total_ms:<12.3f} | {'':<8} |"
    )
    print("=" * 84)
    
    # 최종 목표 달성 여부 판단
    if avg_total_ms < TARGET_TOTAL_TIME_MS:
        print(f"\n✨ 축하합니다! 평균 응답 시간 ({avg_total_ms:.3f}ms)이 최종 목표 ({TARGET_TOTAL_TIME_MS:.1f}ms)를 달성했습니다.")
        print("이는 ONNX 변환 및 INT8 양자화 성공 시 예상되는 성능입니다.")
    else:
        print(f"\n⚠️ 목표 미달성: 평균 응답 시간 ({avg_total_ms:.3f}ms)이 최종 목표 ({TARGET_TOTAL_TIME_MS:.1f}ms)를 초과했습니다.")
        print("시뮬레이션 기반으로는 ONNX 변환 후에도 목표 달성이 어려울 수 있습니다. 실제 모델 성능을 확인해 주세요.")


if __name__ == "__main__":
    filepath = 'test_data.csv'
    sentences = load_data(filepath, SAMPLE_SIZE)
    
    if sentences:
        run_simulation(sentences)
    else:
        print("시뮬레이션을 실행할 문장이 없습니다.")