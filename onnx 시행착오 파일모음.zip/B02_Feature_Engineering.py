import pandas as pd
import numpy as np
import json
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import save_npz # 희소 행렬 저장을 위해 추가

# 🚨 MeCab 로딩 로직 강화: 설치된 MeCab 래퍼에 따라 유연하게 대처합니다.
mecab = None
def custom_tokenizer(doc):
    """MeCab 로드 실패 시 사용하는 대체 토크나이저 (공백 분리)"""
    return doc.split()

try:
    # 1. 'python-mecab-ko' 등 독립적인 MeCab 래퍼를 시도
    from mecab import MeCab
    mecab = MeCab()
    print("[INFO] MeCab (독립 래퍼) 로드 성공.")
except ImportError:
    try:
        # 2. Konlpy를 통한 MeCab을 시도 (표준 경로)
        # 저희는 Konlpy를 설치하지 않았지만, 혹시 모를 경로 호환성 확보
        from konlpy.tag import Mecab
        mecab = Mecab()
        print("[INFO] MeCab (Konlpy 경로) 로드 성공.")
    except ImportError:
        # 3. 모든 시도 실패 시 경고 및 대체 토크나이저 사용
        print("[WARNING] MeCab 로드 실패. 한국어 형태소 분석 대신 공백 분리 토크나이저를 사용합니다.")
        # mecab 변수는 None으로 유지됨
        

# --- 설정 (경로 및 컬럼 이름 수정) ---
CLEAN_DATA_PATH = "cleaned_f2_corpus.csv" # B01 단계에서 생성된 통합 데이터
# JSON 파일 경로 (이전 설정 유지)
JSON_FILE_PATH = r"C:\Users\user\Downloads\data_북엔드(추가)\추가제공데이터\문장교정기록.json" 

# 🚨 수정: 실제 CSV 컬럼 이름인 'original_text' 사용
TEXT_COLUMN_NAME = 'original_text' 
# 레이블 컬럼 이름은 '레이블'로 가정하고 진행합니다. (CSV 파일에 이 컬럼이 있어야 합니다)
TARGET_COLUMN_NAME = '레이블' 

# 피처 및 레이블 저장 경로
OUTPUT_FEATURE_MATRIX = 'X_features.npz' # 피처 행렬 (Compressed Sparse Matrix)
OUTPUT_LABEL_VECTOR = 'y_labels.npy'     # 레이블 벡터


def mecab_tokenizer(doc):
    """
    MeCab을 사용하여 문장을 형태소 단위로 토큰화합니다.
    """
    if mecab is None:
        return custom_tokenizer(doc) # MeCab이 없으면 공백 토크나이저 사용
        
    # MeCab이 로드된 경우
    pos_tags = ['NNG', 'NNP', 'VV', 'VA'] # 일반 명사, 고유 명사, 동사, 형용사
    tokens = mecab.pos(doc)
    
    # 지정된 품사에 해당하는 토큰만 추출하여 공백으로 연결
    return ' '.join([word for word, tag in tokens if tag in pos_tags])


def load_and_augment_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    문장교정기록.json을 로드하고, 이를 활용하여 텍스트 데이터를 보강합니다.
    """
    print(f"[INFO] JSON 파일 로드 중: {JSON_FILE_PATH}")
    try:
        with open(JSON_FILE_PATH, 'r', encoding='utf-8') as f:
            correction_data = json.load(f)
    except FileNotFoundError:
        print(f"[WARNING] JSON 파일 '{JSON_FILE_PATH}'을 찾을 수 없습니다. 텍스트 보강 없이 진행합니다.")
        return df
    except Exception as e:
        print(f"[ERROR] JSON 파일 로드 중 오류 발생: {e}. 텍스트 보강 없이 진행합니다.")
        return df

    correction_map = {item.get('original', '').strip(): item.get('corrected', item.get('original', '')).strip() 
                      for item in correction_data}

    # 원본 텍스트 컬럼이 실제로 존재하는지 확인 후 사용
    if TEXT_COLUMN_NAME not in df.columns:
         raise KeyError(f"지정된 텍스트 컬럼 이름 '{TEXT_COLUMN_NAME}'이 DataFrame에 없습니다. 실제 컬럼명을 확인하세요.")
        
    df['augmented_text'] = df[TEXT_COLUMN_NAME].astype(str).str.strip().apply(
        lambda x: correction_map.get(x, x)
    )
    
    print("[INFO] JSON 데이터를 사용하여 텍스트 보강 완료.")
    return df


def main_feature_engineering():
    print("--- 2단계: 피처 엔지니어링 시작 (MeCab 형태소 분석 및 TF-IDF 벡터화) ---")
    
    # 1. 데이터 로드
    try:
        df = pd.read_csv(CLEAN_DATA_PATH, encoding='utf-8-sig')
    except FileNotFoundError:
        print(f"[FATAL ERROR] 클린 데이터 파일 '{CLEAN_DATA_PATH}'을 찾을 수 없습니다. B01 단계를 먼저 실행하세요.")
        return
    
    # 2. JSON 데이터 활용하여 텍스트 보강
    try:
        df = load_and_augment_data(df)
    except KeyError as e:
        print(f"\n[FATAL ERROR] {e}. 컬럼명을 확인해 주세요.")
        # 이 시점에서 다시 한번 전체 컬럼을 출력하여 최종 확인을 유도합니다.
        print(f"로드가능했던 컬럼명 목록: {df.columns.tolist()}")
        return

    # 3. 텍스트 데이터 형태소 분석 (MeCab)
    print("[INFO] 텍스트 형태소 분석 및 토큰화 시작...")
    
    # 보강된 텍스트를 사용 (없으면 원본 텍스트 사용)
    text_to_process = df['augmented_text'] if 'augmented_text' in df.columns else df[TEXT_COLUMN_NAME]

    # MeCab/Tokenizer 적용
    processed_texts = text_to_process.apply(mecab_tokenizer)
    
    print("[INFO] 토큰화 완료. TF-IDF 벡터화 시작...")

    # 4. TF-IDF 벡터화
    tfidf_vectorizer = TfidfVectorizer(
        min_df=5,       
        ngram_range=(1, 2)
    )
    
    X_sparse = tfidf_vectorizer.fit_transform(processed_texts)
    
    # 5. 레이블 벡터 y 생성
    # 🚨 레이블 컬럼도 존재해야 합니다.
    if TARGET_COLUMN_NAME not in df.columns:
        print(f"\n[FATAL ERROR] 레이블 컬럼 '{TARGET_COLUMN_NAME}'이 DataFrame에 없습니다. 컬럼명을 확인해 주세요.")
        print(f"로드가능했던 컬럼명 목록: {df.columns.tolist()}")
        return

    y = df[TARGET_COLUMN_NAME].astype('category').cat.codes
    
    print(f"\n[RESULT] 피처 행렬(X) 생성 완료: {X_sparse.shape}")
    print(f"[RESULT] 레이블 벡터(y) 생성 완료: {y.shape}")
    print(f"[INFO] 총 {len(tfidf_vectorizer.get_feature_names_out())}개의 피처가 생성되었습니다.")

    # 6. 피처 및 레이블 저장
    save_npz(OUTPUT_FEATURE_MATRIX, X_sparse)
    np.save(OUTPUT_LABEL_VECTOR, y.to_numpy())
    
    print(f"\n[SUCCESS] 피처 엔지니어링 완료.")
    print(f"피처 행렬 저장: {OUTPUT_FEATURE_MATRIX}")
    print(f"레이블 벡터 저장: {OUTPUT_LABEL_VECTOR}")
    
    print("\n--- 데이터 처리 2단계 완료 ---")


if __name__ == "__main__":
    main_feature_engineering()