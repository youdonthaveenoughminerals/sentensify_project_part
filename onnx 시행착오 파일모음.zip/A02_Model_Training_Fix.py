import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import onnx
# skl2onnx의 메인 컨버트 함수 임포트
from skl2onnx import convert_sklearn
from skl2onnx import update_registered_converter # 👈 컨버터 등록을 위해 다시 추가

# LightGBM 모델 클래스 임포트
from lightgbm.sklearn import LGBMClassifier

# 🚨 최종 해결을 위한 임포트: onnxmltools에서 LightGBM 컨버터 직접 가져오기
try:
    # 1. Converter 경로: LightGbm (정확)
    from onnxmltools.convert.lightgbm.operator_converters.LightGbm import convert_lightgbm
    
    # 2. Shape Calculator 경로 및 함수 이름: Classifier.py에서 확인된 정확한 이름 적용
    from onnxmltools.convert.lightgbm.shape_calculators.Classifier import calculate_lightgbm_classifier_output_shapes
    
    # LGBMClassifier 클래스에 누락된 변환 함수를 수동으로 등록합니다.
    update_registered_converter(
        LGBMClassifier,
        'LightGbmLGBMClassifier',
        calculate_lightgbm_classifier_output_shapes, # 셰이프 계산기 등록 (최종 확정된 함수 이름)
        convert_lightgbm,                       # 컨버터 등록
        options={'nocl': [True, False], 'zipmap': [True, False], 'output_class_scores': [True, False]}
    )
    print("✅ LightGBM 컨버터 수동 등록 성공 (최종 함수 이름 적용).")
    
except ImportError as e:
    # 이 오류는 이제 더 이상 패키지 버전 문제가 아닌, 경로 내 파일 이름 불일치 문제입니다.
    print(f"🚨 onnxmltools 임포트 오류. 수동 등록 재시도 실패: {e}")
    print("🚨🚨 내부 함수 이름이 불일치할 수 있습니다. 다음 단계로 진행해주세요. 🚨🚨")
    
# ******************************************************************************

from skl2onnx.common.data_types import FloatTensorType
import os
import sys


print("--- LightGBM ONNX 변환 준비 시작 ---")

# 1. 가상 데이터셋 생성 및 인코딩
# 실제 프로젝트에서는 이 부분을 북엔드 데이터로 대체해야 합니다.
data_size = 500
np.random.seed(42)
data = pd.DataFrame({
    # 숫자/범주형 특성으로 가정합니다.
    'feature_1': np.random.randint(20, 200, size=data_size),
    'feature_2': np.random.randint(0, 2, size=data_size),
    'feature_3': np.random.rand(data_size).round(1),
    # 교정 옵션 추천을 위한 타겟 카테고리 (예: '공식', '일상', '비즈니스')
    'target_category': np.random.choice(['A', 'B', 'C', 'D'], size=data_size)
})

# 타겟 레이블 인코딩
le = LabelEncoder()
data['target_label'] = le.fit_transform(data['target_category'])

X = data[['feature_1', 'feature_2', 'feature_3']]
y = data['target_label']
X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Pandas/Numpy 데이터 준비 성공. 학습 데이터 크기: {X_train.shape}")

# 2. LightGBM 모델 학습
# 다중 클래스 분류 모델로 설정 (추천 옵션 A, B, C, D 중 하나를 선택하는 문제)
lgbm = lgb.LGBMClassifier(objective='multiclass', 
                          metric='multi_logloss', 
                          n_estimators=100, 
                          random_state=42,
                          n_jobs=-1,  # 빠른 학습을 위해 모든 코어 사용
                          verbose=-1) # 경고 메시지 숨김

print("LightGBM 모델 학습 시작...")
try:
    lgbm.fit(X_train, Y_train)
    print("LightGBM 모델 학습 완료.")
except Exception as e:
    print(f"🚨 LightGBM 학습 중 오류 발생: {e}")
    sys.exit(1)

# --- ONNX 변환 시작 ---
print("\n--- ONNX 변환 시작 ---")

try:
    # 3. 입력 데이터 형태 정의
    initial_type = [('float_input', FloatTensorType([None, X_train.shape[1]]))]
    
    # ONNX 형식으로 모델 변환
    # 🚨 수정: target_opset을 딕셔너리 형태로 지정하여 ai.onnx.ml 도메인 버전을 2로 고정
    onnx_model = convert_sklearn(
        lgbm, 
        initial_types=initial_type, 
        target_opset={'': 13, 'ai.onnx.ml': 2}
    )

    # 4. ONNX 모델 파일로 저장
    model_path = "lgbm_model.multiclass.onnx" 
    
    with open(model_path, "wb") as f:
        f.write(onnx_model.SerializeToString())

    # *******************************************************************
    # ★★★★ 최종 확인 출력 추가 ★★★★
    print("*" * 50)
    print(f"✅ ONNX 변환 성공: 모델이 다음 경로에 저장되었습니다: {os.path.abspath(model_path)}")
    print("*" * 50)
    print("--- 2주차 ONNX 목표 완료 ---")
    # *******************************************************************

except Exception as e:
    # ★★★★ 오류 메시지 강제 출력 ★★★★
    print(f"\n❌ ONNX 변환 중 치명적인 오류 발생! 오류 내용: {e}", file=sys.stderr)
    print("\n--- ❗ LightGBM 컨버터 경로 오류: 패키지 버전이 호환되지 않습니다. 다음 단계로 진행해주세요. ❗ ---")
    sys.exit(1)