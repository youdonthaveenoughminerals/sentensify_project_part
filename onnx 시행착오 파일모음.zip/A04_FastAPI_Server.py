import onnxruntime
import numpy as np
import pandas as pd
from fastapi import FastAPI
from pydantic import BaseModel, Field
import uvicorn
import time
from typing import List, Dict, Union

# --- 1. ONNX 모델 로드 및 추론 환경 설정 ---

MODEL_PATH = "lgbm_model.multiclass.onnx"
# ONNX Runtime InferenceSession을 초기화 (서버 시작 시 한 번만 실행)
try:
    ONNX_SESSION = onnxruntime.InferenceSession(MODEL_PATH, providers=['CPUExecutionProvider'])
    INPUT_NAME = ONNX_SESSION.get_inputs()[0].name 
    print(f"✅ ONNX 모델 로드 성공: {MODEL_PATH}")
except Exception as e:
    print(f"❌ ONNX 모델 로드 오류: {e}")
    # 모델 로드에 실패하면 서버를 시작할 수 없습니다.
    ONNX_SESSION = None

# --- 2. API 스키마 정의 (project_schemas.md 기반) ---

# 1.1. 텍스트 메타데이터 스키마
class TextMetadata(BaseModel):
    """텍스트의 문맥 정보를 담는 스키마."""
    topic: str = Field(..., description="텍스트의 주제 (e.g., '보고서', '에세이')")
    tone: str = Field(..., description="텍스트의 문체 (e.g., '공식적', '비공식적')")

# 1.1. API 입력 스키마 (교정 추천 요청)
class CorrectionRequest(BaseModel):
    user_id: str = Field(..., description="사용자 고유 ID (히스토리 임베딩 추출용)")
    input_text: str = Field(..., description="교정을 요청하는 실제 텍스트")
    lang_code: str = Field('ko', description="현재 텍스트 언어 ('ko' 우선)")
    current_intensity: int = Field(2, ge=1, le=3, description="사용자가 현재 선택한 교정 강도 (1: 약, 2: 중, 3: 강)")
    text_metadata: TextMetadata

# 1.2. API 출력 스키마 (교정 추천 응답)
class RecommendationResponse(BaseModel):
    recommended_option_id: int = Field(..., description="LightGBM ONNX 모델의 최종 예측 레이블 (0, 1, 2, 3)")
    option_name: str = Field(..., description="추천 옵션 이름 (e.g., '문법 및 맞춤법 강화')")
    justification: str = Field(..., description="추천 이유 (문맥 기반 설명)")
    current_intensity: int = Field(..., description="추천 강도 (1, 2, 3 중 하나)")

# --- 3. 핵심 로직 함수 ---

# LightGBM 출력 레이블 해석 (project_schemas.md 섹션 3)
OPTION_MAPPING = {
    0: {"name": "기본 맞춤법 및 문법 교정", "desc": "정확성, 오타/띄어쓰기 최소화"},
    1: {"name": "문체 및 어휘 강화 교정", "desc": "스타일, 표현의 자연스러움 증진"},
    2: {"name": "논리 및 흐름 개선 교정", "desc": "구조, 논리적 흐름 개선"},
    3: {"name": "외국어 특화 교정", "desc": "한국어 외 언어에 대한 특화된 문법 및 용어 사용"},
}

# 3.1. ONNX 확률 결과 클렌징 함수 (03_ONNX_Test.py에서 가져옴)
def clean_onnx_probas(raw_onnx_proba_preds: Union[List[Dict], np.ndarray]) -> np.ndarray:
    """List of Dicts 형태의 확률 결과를 2차원 Numpy 배열로 변환."""
    if isinstance(raw_onnx_proba_preds, list) and isinstance(raw_onnx_proba_preds[0], dict):
        class_ids = sorted(raw_onnx_proba_preds[0].keys())
        cleaned_probas = []
        for item in raw_onnx_proba_preds:
            probas = [item[cid] for cid in class_ids]
            cleaned_probas.append(probas)
        return np.array(cleaned_probas, dtype=np.float32)
    return raw_onnx_proba_preds

# 3.2. 가짜 데이터 추출 시뮬레이션 함수 (Embedding + Model Input)
# 실제로는 여기서 user_id를 기반으로 DB에서 임베딩 벡터를 가져옵니다.
def simulate_feature_extraction(request: CorrectionRequest) -> np.ndarray:
    """API 요청으로부터 모델 입력 피처(3개)를 생성하는 시뮬레이션."""
    
    # 🚨 데모 시연용 가짜 로직 🚨
    # user_id와 metadata에 따라 LightGBM의 3개 피처 값을 임의로 설정합니다.
    
    # 1. F1: 텍스트 길이/복잡도 (input_text 길이의 함수로 모방)
    f1 = min(len(request.input_text) * 2, 200) 
    
    # 2. F2: 텍스트의 공식성/비공식성 (topic과 tone에 따라 0 또는 1로 모방)
    if request.text_metadata.tone == '공식적' or request.text_metadata.topic == '보고서':
        f2 = 1 
    else:
        f2 = 0
        
    # 3. F3: 사용자 교정 강도 (0.0 ~ 1.0 사이의 값으로 모방)
    f3 = request.current_intensity / 3.0
    
    # ONNX 모델은 (1, 3) float32 형태의 입력을 요구합니다.
    # [feature_1, feature_2, feature_3]
    return np.array([[f1, f2, f3]], dtype=np.float32)

# 3.3. ONNX 모델 추론 함수
def predict_with_onnx(model_input: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """ONNX 모델을 실행하고 레이블과 확률을 반환합니다."""
    # 추론 실행
    onnx_results = ONNX_SESSION.run(None, {INPUT_NAME: model_input})
    onnx_label_preds = onnx_results[0]
    raw_onnx_proba_preds = onnx_results[1]
    
    # 확률 클렌징
    onnx_proba_preds = clean_onnx_probas(raw_onnx_proba_preds)
    
    return onnx_label_preds, onnx_proba_preds

# --- 4. FastAPI 앱 정의 ---
app = FastAPI(title="북엔드 ONNX 추천 서버", version="0.1.0")

@app.post("/recommend_correction", response_model=RecommendationResponse)
async def recommend_correction(request: CorrectionRequest):
    """
    사용자 요청과 텍스트 문맥을 기반으로 최적의 교정 옵션을 추천합니다.
    """
    if ONNX_SESSION is None:
        raise HTTPException(status_code=503, detail="모델 서버가 초기화되지 않았습니다.")

    # 1. 모델 입력 피처 생성 (가짜 데이터 기반)
    model_input = simulate_feature_extraction(request)

    # 2. ONNX 모델 추론
    label_preds, proba_preds = predict_with_onnx(model_input)
    
    # 최종 예측 레이블 (가장 높은 확률)
    recommended_id = int(label_preds[0]) # (1,) 크기의 배열이므로 첫 번째 요소를 가져옵니다.
    
    # 3. 문맥 기반 정당화 (Justification) 생성 🚨 데모 로직 🚨
    option_info = OPTION_MAPPING.get(recommended_id, OPTION_MAPPING[0])
    
    justification = (
        f"요청하신 텍스트의 주제 '{request.text_metadata.topic}'과 문체 '{request.text_metadata.tone}'을 분석한 결과, "
        f"과거 사용자 기록(ID: {request.user_id})을 고려하여 {option_info['name']}을(를) 추천합니다. "
        f"현재 설정된 강도({request.current_intensity})에 맞춰 {option_info['desc']}에 집중합니다."
    )

    # 4. 응답 스키마 반환
    return RecommendationResponse(
        recommended_option_id=recommended_id,
        option_name=option_info["name"],
        justification=justification,
        current_intensity=request.current_intensity
    )

@app.get("/")
async def health_check():
    """서버 상태 확인"""
    return {"status": "ok", "model_loaded": ONNX_SESSION is not None, "time": time.time()}

# --- 5. 서버 실행 (로컬 테스트용) ---
# 이 파일 자체를 실행하면 서버가 시작됩니다.
if __name__ == "__main__":
    # uvicorn.run(app, host="127.0.0.1", port=8000)
    # 실제 데모를 위해서는 아래 명령어를 cmd에서 직접 실행해야 합니다.
    print("\n--- 서버 실행 준비 완료 ---")
    print("데모 서버를 시작하려면 다음 명령어를 CMD에서 실행하세요:")
    print("uvicorn 04_FastAPI_Server:app --reload")