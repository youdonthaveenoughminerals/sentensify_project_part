# sentensify_core_api.py
# Sentensify 웹 서비스의 핵심 로직: 실시간 문장 교정 및 개인화된 강화 추론 API 시뮬레이션
# 기업 제공 데이터 (사용량, 이벤트 피드백)를 활용하여 로직을 강화합니다.

import numpy as np 
import random
import json
from typing import Dict, Any, Optional

# --- 1. 전역 설정 및 상수 ---

# ONNX 모델이 예측할 도메인 목록
DOMAIN_LABELS = ["기사", "상담", "마케팅", "논문", "보고서", "일반"]

# LLM 시뮬레이션을 위한 파라미터
LLM_CONFIDENCE_THRESHOLD = 0.85 # ONNX 확신도가 0.85 미만일 때 LLM 개입 기준점
TARGET_CONFIDENCE_LLM = 0.95 # LLM이 개입했을 때 강제할 최종 최소 확신도

# --- 데이터베이스 Mock (JSON 파일 시뮬레이션) ---

# user_usage_data.json 시뮬레이션 (사용 횟수)
USER_STATS_DB = {
    "expert_editor_22": {"usage_count": 5200, "is_power_user": True},
    "casual_user_03": {"usage_count": 50, "is_power_user": False},
    "data_driven_user": {"usage_count": 1500, "is_power_user": True},
    "default_user": {"usage_count": 1, "is_power_user": False}, # 기본 사용자 추가
}
# event_data.json 시뮬레이션 (LLM 교정 만족도 -1.0 ~ 1.0)
USER_FEEDBACK_DB = {
    "expert_editor_22": 0.85, # 매우 만족 (자주 복사함)
    "casual_user_03": 0.10, # 불만족 (거의 복사 안 함)
    "data_driven_user": 0.55,
    "default_user": 0.50, # 기본 사용자 평균 만족도
}

# --- 2. 데이터 조회 함수 (JSON 파일 활용 시뮬레이션) ---

def get_user_stats(user_id: str) -> Dict[str, Any]:
    """ user_usage_data.json을 기반으로 사용자 통계를 가져옵니다. """
    # user_id가 DB에 없을 경우 "default_user"의 통계를 반환하여 오류를 방지합니다.
    return USER_STATS_DB.get(user_id, USER_STATS_DB["default_user"])

def get_user_feedback_score(user_id: str) -> float:
    """ event_data.json을 기반으로 LLM 교정에 대한 사용자의 만족도 (피드백) 점수를 가져옵니다. """
    # user_id가 DB에 없을 경우 기본값 0.5를 반환하여 오류를 방지합니다.
    return USER_FEEDBACK_DB.get(user_id, 0.50)

# --- 3. 모델 시뮬레이션 함수 (기존 유지) ---

def preprocess_text(text: str) -> np.ndarray:
    """ 텍스트를 ONNX 모델 입력 형태(특성)로 변환합니다. """
    hash_value = hash(text) % 1000
    feature_1 = len(text) / 100.0
    feature_2 = (hash_value % 10) / 10.0
    feature_3 = (hash_value % 7) / 7.0
    return np.array([[feature_1, feature_2, feature_3]], dtype=np.float32)

def run_onnx_model(features: np.ndarray) -> tuple[int, float]:
    """ 경량 ONNX 모델의 1차 예측 시뮬레이션 (빠른 도메인 분류). """
    pred_index = int(features[0, 0] * 5) % len(DOMAIN_LABELS)
    max_conf = np.clip(0.4 + features[0, 1] * 0.4 - features[0, 2] * 0.1, 0.1, 0.9)
    return pred_index, max_conf

# --- 4. 개인화된 LLM 교정/추론 로직 (강화) ---

def simulate_llm_personalization(
    user_id: str, 
    initial_conf: float, 
    user_stats: Dict[str, Any], 
    feedback_score: float
) -> tuple[float, float, bool]:
    """
    사용자 데이터(사용량, 피드백)를 기반으로 LLM의 교정 강도와 최종 확신도를 개인화합니다.
    """
    
    # 1. 확신도 강화: 피드백 점수에 따라 최종 확신도의 하한선 미세 조정
    confidence_boost = feedback_score * 0.04 
    final_conf = random.uniform(TARGET_CONFIDENCE_LLM + confidence_boost, 0.99)
    
    # 2. 교정 강도 강화: 파워 유저(사용량 多)는 더 미묘한 교정(낮은 강도)을 선호한다고 가정
    base_strength = 0.9
    if user_stats.get("is_power_user"):
        # 파워 유저는 덜 공격적인 교정 (0.7 ~ 0.85)
        base_strength = random.uniform(0.7, 0.85)
    else:
        # 일반 유저는 더 적극적인 교정 (0.85 ~ 1.0)
        base_strength = random.uniform(0.85, 1.0)

    correction_strength = np.clip(base_strength * (1 + (feedback_score - 0.5) * 0.2), 0.6, 1.0)
    
    # 3. 도메인 교정 여부 결정: 피드백 점수가 높을수록 LLM이 ONNX 예측을 뒤집을 확률을 높입니다.
    should_correct = random.random() < (0.1 + feedback_score * 0.4) 

    return final_conf, correction_strength, should_correct

def llm_correction_and_inference(
    sentence: str, 
    initial_domain_idx: int, 
    initial_conf: float, 
    user_id: str,
    user_stats: Dict[str, Any],
    feedback_score: float
) -> Dict[str, Any]:
    """ LLM을 호출하여 최종 교정 문장과 추론 확신도를 결정합니다. """
    initial_domain = DOMAIN_LABELS[initial_domain_idx]

    # 1. 데이터 기반 개인화된 파라미터 결정
    final_conf, correction_strength, should_correct = simulate_llm_personalization(
        user_id, initial_conf, user_stats, feedback_score
    )
    
    # 2. 최종 도메인 결정 
    if should_correct:
        new_domain_idx = (initial_domain_idx + 1) % len(DOMAIN_LABELS)
        final_domain = DOMAIN_LABELS[new_domain_idx]
        correction_type = "데이터 기반 강력 교정 (도메인 변경)"
    else:
        final_domain = initial_domain
        correction_type = "데이터 기반 약한 교정 (확신도/스타일 조정)"

    # 3. 교정 문장 생성 시뮬레이션
    corrected_text = (
        f"{sentence} [개인화된 강화 추론 완료. "
        f"최종 도메인: {final_domain}, 확신도: {final_conf:.4f}, 피드백 적용 강도: {correction_strength:.4f}]"
    )
        
    return {
        "final_domain": final_domain,
        "final_conf": final_conf,
        "correction_strength": correction_strength,
        "corrected_sentence": corrected_text,
        "correction_type": correction_type,
        "user_id": user_id
    }

# --- 5. 통합 API 엔드포인트 시뮬레이션 (강화) ---

def process_sentence(sentence: str, user_id: str = "default_user") -> Dict[str, Any]:
    """
    Sentensify의 실시간 문장 처리 API 엔드포인트 역할을 수행합니다.
    ONNX와 LLM을 통합하고 사용자 데이터를 활용하여 최적의 결과를 반환합니다.
    """
    # 1. 사용자 데이터 로드
    user_stats = get_user_stats(user_id)
    feedback_score = get_user_feedback_score(user_id)
    is_power_user = user_stats.get("is_power_user", False)
    
    # 2. ONNX 전처리 및 실행
    features = preprocess_text(sentence)
    initial_idx, initial_conf = run_onnx_model(features)
    
    # 3. LLM 개입 역치 조정 (사용량 데이터 활용)
    # 파워 유저일 경우, LLM 개입 임계치를 미세하게 높여 품질 검증을 강화합니다.
    adjusted_threshold = LLM_CONFIDENCE_THRESHOLD
    if is_power_user:
        adjusted_threshold = 0.88 # 0.03 상향 조정
        
    is_llm_called = initial_conf < adjusted_threshold

    if not is_llm_called:
        # LLM 미개입: ONNX 결과 확정
        return {
            "input_sentence": sentence,
            "final_domain": DOMAIN_LABELS[initial_idx],
            "final_conf": initial_conf,
            "correction_strength": 0.0,
            "is_llm_called": False,
            "corrected_sentence": sentence,
            "reasoning": f"ONNX 확신도 {initial_conf:.4f}가 (역치 {adjusted_threshold:.2f}보다 높아) LLM 개입 없이 빠르게 처리됨."
        }
    else:
        # LLM 개입: 개인화된 강화 교정/추론 실행
        llm_result = llm_correction_and_inference(
            sentence, initial_idx, initial_conf, user_id, user_stats, feedback_score
        )
        return {
            "input_sentence": sentence,
            "initial_domain_onnx": DOMAIN_LABELS[initial_idx],
            "initial_conf_onnx": initial_conf,
            "is_llm_called": True,
            "final_domain": llm_result["final_domain"],
            "final_conf": llm_result["final_conf"],
            "correction_strength": llm_result["correction_strength"],
            "corrected_sentence": llm_result["corrected_sentence"],
            "reasoning": (
                f"LLM 개입 ({llm_result['correction_type']}). "
                f"사용자 '{user_id}'의 사용량/피드백을 반영하여 교정 스타일 및 확신도가 강화됨."
            )
        }


# --- 6. 테스트 케이스 (데이터 활용 시뮬레이션) ---

if __name__ == "__main__":
    
    test_sentences = [
        "이 제품은 뛰어난 사용자 경험과 직관적인 인터페이스를 제공하여 시장의 기대를 뛰어넘을 것입니다.",
        "본 연구는 딥러닝 기반의 자연어 처리 모델을 활용하여 구문 분석 오류율을 최소화하는 방안을 제시한다.",
    ]
    
    user_a = "expert_editor_22" # 파워 유저 (사용량 多, LLM 만족도 高)
    user_b = "casual_user_03" # 일반 유저 (사용량 少, LLM 만족도 低)
    user_c = "data_driven_user" # 중간 유저 (사용량 中, LLM 만족도 中)

    print("="*100)
    print(" Sentensify 실시간 API 시뮬레이션: 사용자 데이터(사용량/피드백) 통합 ")
    print("="*100)
    
    for user_id in [user_a, user_b, user_c]:
        print(f"\n[--- 사용자: {user_id} (사용량: {get_user_stats(user_id)['usage_count']}회, 피드백: {get_user_feedback_score(user_id):.2f}) ---]")
        for sentence in test_sentences:
            result = process_sentence(sentence, user_id)
            
            # LLM 개입 역치 표시를 위한 임계값 재계산
            stats = get_user_stats(user_id)
            threshold = 0.88 if stats.get("is_power_user") else 0.85

            print("-" * 70)
            print(f"입력: {result['input_sentence'][:30]}...")
            # ONNX 결과가 있는 경우에만 표시
            initial_domain = result.get('initial_domain_onnx', 'N/A')
            initial_conf = result.get('initial_conf_onnx', 0)
            
            print(f"ONNX 예측: {initial_domain}/{initial_conf:.4f} (개입 역치: {threshold:.2f})")
            print(f"LLM 개입: {'YES' if result['is_llm_called'] else 'NO'} | 최종 도메인: {result['final_domain']}")
            print(f"최종 확신도: {result['final_conf']:.4f} | 교정 강도: {result['correction_strength']:.4f} (피드백 반영)")
            print(f"Reasoning: {result['reasoning']}")

    print("\n" + "="*100)
    print(" 시뮬레이션 완료. 사용자 데이터가 LLM 개입 여부와 교정 스타일을 결정하는 데 활용됨을 확인했습니다. ")
    print("="*100)