import csv
import random
import time
import math
from collections import defaultdict
import io # 파일 저장을 위해 io 모듈 추가

# --- 상수 정의 ---
# 목표 Latency (ms)
TARGET_STEP1_MS = 3.0  # 형식 추론 (ONNX)
TARGET_STEP2_MS = 2.5  # DB 로드 (Embedding Search)
TARGET_STEP3_MS = 3.0  # 교정 추론 (LLM/ONNX)
TARGET_FINAL_MS = TARGET_STEP1_MS + TARGET_STEP2_MS + TARGET_STEP3_MS # 8.5ms
SIMULATION_ACCURACY_RATE = 0.85
OUTPUT_FILE = "analysis_report.txt" # 결과를 저장할 파일명

# --- 유틸리티 함수 ---

def load_test_data(filepath="test_data.csv"):
    """
    test_data.csv 파일에서 문장 내용과 정답 필드를 로드합니다.
    CSV 구조: content,field (헤더 포함)
    """
    sentences = []
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                sentences.append({
                    "content": row['content'],
                    "true_field": row['field']
                })
        return sentences
    except FileNotFoundError:
        print(f"🚨 오류: {filepath} 파일을 찾을 수 없습니다. 시뮬레이션을 위해 내부 임시 데이터를 사용합니다.")
        # 파일이 없을 경우, 시뮬레이션을 위한 임시 데이터 반환 (약 100개로 늘림)
        default_data = [
            {"content": "이번 연구는 인공지능 기반의 새로운 추천 시스템의 성능 개선에 초점을 맞추었다.", "true_field": "논문"},
            {"content": "최신 트렌드를 반영한 마케팅 전략은 소비자들의 폭발적인 반응을 이끌어냈습니다.", "true_field": "마케팅"},
            {"content": "가나다라 마바사 아자차카 타파하", "true_field": "일반"},
            {"content": "전문가들은 이 보고서가 향후 5년간의 산업 동향을 정확히 예측하고 있다고 분석했습니다.", "true_field": "보고서"},
            {"content": "긴급 속보: 서울 지역에 사상 최악의 집중 호우가 발생하여 심각한 피해가 우려됩니다.", "true_field": "기사"},
            {"content": "새로운 서비스 출시를 기념하여 특별 프로모션을 진행합니다. 놓치지 마세요!", "true_field": "마케팅"},
            {"content": "기계학습 모델의 과적합 방지를 위한 드롭아웃 기법의 효과를 실험적으로 검증하였다.", "true_field": "논문"},
            {"content": "본 프로젝트의 진행 상황과 주요 이슈를 정리하여 주간 보고서 형태로 제출합니다.", "true_field": "보고서"},
            {"content": "정치권은 이 문제에 대해 여전히 첨예한 대립을 이어가고 있으며, 돌파구를 찾기 어려운 상황입니다.", "true_field": "기사"},
            {"content": "오늘 점심은 무엇을 먹을까요? 김치찌개, 된장찌개, 아니면 부대찌개?", "true_field": "일반"},
        ]
        # 100개의 임시 데이터 생성을 위해 복제
        return (default_data * 10)[:100]

def simulate_step_time(target_ms):
    """목표 시간 주변으로 랜덤 노이즈를 추가하여 시뮬레이션 시간을 반환 (ms 단위)"""
    noise = (random.random() * 0.1) - 0.05
    simulated_ms = target_ms * (1 + noise)
    return max(2.0, simulated_ms)

def simulate_prediction(true_field, all_categories):
    """정확도율에 따라 예측 결과와 오답 결과를 시뮬레이션하여 반환합니다."""
    if random.random() < SIMULATION_ACCURACY_RATE:
        # 정답일 경우 (85%)
        predicted_field = true_field
        is_correct = "O"
    else:
        # 오답일 경우 (15%)
        wrong_categories = [c for c in all_categories if c != true_field]
        if wrong_categories:
            predicted_field = random.choice(wrong_categories)
        else:
            predicted_field = true_field 
        is_correct = "X"
    
    return predicted_field, is_correct

def format_report_output(results, avg_metrics, total_count, correct_predictions):
    """보고서 내용을 문자열로 포맷하여 반환 (콘솔 및 파일 저장용)"""
    s = io.StringIO()

    # 1. 헤더
    s.write("=" * 120 + "\n")
    s.write("| {:^116} |\n".format("ONNX 및 DB 성능/정확도 분석 결과"))
    s.write("| {:^116} |\n".format(f"목표 Latency: {TARGET_FINAL_MS:.1f}ms / 시뮬레이션 정확도: {SIMULATION_ACCURACY_RATE*100:.0f}%"))
    s.write("=" * 120 + "\n")

    # 2. 테이블 헤더
    header_format = "| {:<8} | {:<7} | {:<12} | {:<10} | {:<10} | {:<10} | {:<10} | {:<10} | {:<7} |\n"
    s.write(header_format.format(
        "문장 번호", "문자 수", "형식 추론 (ms)", "DB 로드 (ms)", "교정 추론 (ms)", 
        "총 시간 (ms)", "예측 결과", "정답 필드", "정확도"
    ))
    s.write("-" * 120 + "\n")

    # 3. 개별 결과
    data_format = "| {:<8} | {:<7} | {:<12.3f} | {:<10.3f} | {:<10.3f} | {:<10.3f} | {:<10} | {:<10} | {:<7} |\n"
    for res in results:
        s.write(data_format.format(
            res['num'], res['char_count'], res['time_s1'], res['time_s2'], res['time_s3'], 
            res['total_time'], res['predicted_field'], res['true_field'], res['is_correct']
        ))
    
    s.write("-" * 120 + "\n")
    
    # 4. 평균 결과
    avg_time_total = avg_metrics['total_time']
    avg_summary = header_format.format(
        "평균", "", avg_metrics['time_s1'], avg_metrics['time_s2'], avg_metrics['time_s3'], 
        avg_time_total, "", "", ""
    )
    s.write(avg_summary)
    s.write("=" * 120 + "\n")

    # 5. 최종 요약
    accuracy = (correct_predictions / total_count) * 100
    s.write("✨ 최종 요약:\n")
    s.write(f"   - 평균 응답 시간: {avg_time_total:.3f}ms (목표 {TARGET_FINAL_MS:.1f}ms)\n")
    s.write(f"   - **분류 정확도 (Accuracy): {accuracy:.2f}%** ({correct_predictions}/{total_count} 정답)\n")
    
    if avg_time_total <= TARGET_FINAL_MS and accuracy >= SIMULATION_ACCURACY_RATE * 100:
        s.write("   - ✅ 성능 및 정확도 모두 목표치에 도달했습니다!\n")
    elif avg_time_total <= TARGET_FINAL_MS:
        s.write("   - ⚠️ 성능은 목표를 달성했으나, 정확도 개선이 필요합니다.\n")
    elif accuracy >= SIMULATION_ACCURACY_RATE * 100:
        s.write("   - ⚠️ 정확도는 목표를 달성했으나, 성능 최적화가 더 필요합니다.\n")
    else:
        s.write("   - ❌ 성능 및 정확도 모두 목표치에 미달합니다. 전반적인 최적화가 필요합니다.\n")
        
    return s.getvalue()

def write_results_to_file(content, filepath):
    """결과 내용을 파일로 저장합니다."""
    try:
        # 윈도우 환경에서도 안전하게 파일을 쓰기 위해 'utf-8' 인코딩 사용
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True, filepath
    except Exception as e:
        return False, str(e)

# --- 메인 실행 로직 ---

def run_analysis():
    # 1. 데이터 로드 및 초기 설정
    data = load_test_data()
    if not data:
        print("🚨 오류: 시뮬레이션을 위한 데이터가 없습니다. 파일을 확인하거나 내부 데이터를 추가하세요.")
        return

    all_categories = sorted(list(set([d['true_field'] for d in data])))
    
    total_count = len(data)
    results = []
    total_time_s1, total_time_s2, total_time_s3, total_time_sum = 0, 0, 0, 0
    correct_predictions = 0

    print(f"✅ 총 {total_count}개의 문장을 처리합니다.")
    print("-" * 120)

    # 2. 시뮬레이션 루프
    for i, item in enumerate(data):
        # 1) 시간 시뮬레이션
        time_s1 = simulate_step_time(TARGET_STEP1_MS)
        time_s2 = simulate_step_time(TARGET_STEP2_MS)
        time_s3 = simulate_step_time(TARGET_STEP3_MS)
        total_time = time_s1 + time_s2 + time_s3

        # 2) 정확도 시뮬레이션
        predicted_field, is_correct = simulate_prediction(item['true_field'], all_categories)
        
        if is_correct == "O":
            correct_predictions += 1

        # 3) 결과 저장 및 합산
        results.append({
            "num": i + 1,
            "char_count": len(item['content']),
            "time_s1": time_s1,
            "time_s2": time_s2,
            "time_s3": time_s3,
            "total_time": total_time,
            "predicted_field": predicted_field,
            "true_field": item['true_field'],
            "is_correct": is_correct
        })

        total_time_s1 += time_s1
        total_time_s2 += time_s2
        total_time_s3 += time_s3
        total_time_sum += total_time
        
    # 3. 평균 계산
    avg_metrics = {
        "time_s1": total_time_s1 / total_count,
        "time_s2": total_time_s2 / total_count,
        "time_s3": total_time_s3 / total_count,
        "total_time": total_time_sum / total_count,
    }
    
    # 4. 보고서 포맷팅 및 출력/저장
    report_content = format_report_output(results, avg_metrics, total_count, correct_predictions)
    
    # CMD 콘솔 출력 (전체 보고서 내용이 출력됨)
    print(report_content)
    
    # 파일 저장
    success, path = write_results_to_file(report_content, OUTPUT_FILE)
    if success:
        print(f"\n📄 전체 보고서가 파일로 저장되었습니다: {path}")
    else:
        print(f"\n🚨 파일 저장 오류: {path}")

# 스크립트 실행
if __name__ == "__main__":
    run_analysis()