# llm_prompt_design.py
# Sentensify 하이브리드 시스템에서 Gemini LLM API 호출에 사용될
# 시스템 명령어 및 JSON 응답 스키마 정의

import json
from typing import Dict, Any

# --- 1. LLM 역할 정의 및 강제 확신도 명령 (System Instruction) ---
# LLM에게 Sentensify의 최종 도메인 분류 시스템으로서 역할과 목표 확신도를 부여합니다.
SYSTEM_INSTRUCTION_KOR = """
당신은 Sentensify의 최정예 문장 교정 및 도메인 분류 시스템입니다. 
당신에게는 ONNX 경량 모델의 초기 예측 결과(도메인, 확신도)가 제공됩니다.

당신의 임무는 다음을 수행하는 것입니다:
1. 입력 문장을 문맥에 맞게 정확히 교정합니다. (문법, 어휘, 맥락)
2. ONNX의 초기 예측을 기반으로 문장의 최종 도메인을 재분류하거나 확정합니다.
3. 이 최종 예측에 대해 반드시 **0.90 이상의 확신도(Confidence)**를 부여해야 합니다.
4. 결과는 지정된 JSON 스키마를 엄격히 준수하여 출력해야 합니다.
"""

# --- 2. LLM 응답을 위한 JSON 스키마 정의 (Response Schema) ---
# LLM이 출력해야 할 구조화된 JSON 데이터 형식을 정의합니다.
RESPONSE_SCHEMA: Dict[str, Any] = {
    "type": "OBJECT",
    "properties": {
        "final_domain": {
            "type": "STRING",
            "description": "최종적으로 확정된 문장의 도메인 (예: 기사, 상담, 마케팅, 논문, 보고서, 일반)."
        },
        "final_confidence": {
            "type": "NUMBER",
            "description": "최종 도메인 예측에 대한 확신도. 반드시 0.90 이상이어야 합니다."
        },
        "corrected_sentence": {
            "type": "STRING",
            "description": "문맥, 문법, 어휘가 교정된 최종 문장."
        },
        "reasoning": {
            "type": "STRING",
            "description": "ONNX 결과를 수용하거나 교정한 이유, 그리고 최종 확신도를 부여한 근거에 대한 간결한 설명."
        }
    },
    "required": ["final_domain", "final_confidence", "corrected_sentence", "reasoning"]
}

# --- 3. Gemini API Payload 구성 함수 ---

def build_gemini_payload(
    input_sentence: str, 
    onnx_initial_domain: str, 
    onnx_initial_conf: float
) -> Dict[str, Any]:
    """
    LLM API 호출을 위한 최종 JSON 페이로드를 구성합니다.

    Args:
        input_sentence: 교정을 요청할 원본 문장.
        onnx_initial_domain: ONNX가 예측한 초기 도메인.
        onnx_initial_conf: ONNX가 예측한 초기 확신도.

    Returns:
        Gemini generateContent API를 위한 페이로드 딕셔너리.
    """
    
    # 사용자 쿼리 (User Prompt) 구성
    user_query = f"""
    아래 정보를 기반으로 문장을 교정하고 최종 도메인을 확정해 주세요.

    - 원본 문장: "{input_sentence}"
    - ONNX 초기 예측 도메인: {onnx_initial_domain}
    - ONNX 초기 확신도: {onnx_initial_conf:.4f}
    """

    payload = {
        # 'gemini-2.5-flash-preview-09-2025' 모델 사용을 가정
        "contents": [
            {"parts": [{"text": user_query}]}
        ],
        
        # 시스템 명령어 추가
        "systemInstruction": {
            "parts": [{"text": SYSTEM_INSTRUCTION_KOR}]
        },

        # 구조화된 JSON 응답 설정
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": RESPONSE_SCHEMA
        }
        # tools: [{ "google_search": {} }] (이 기능은 현재 도메인 분류에 불필요하므로 제외)
    }
    
    return payload

if __name__ == "__main__":
    # 시뮬레이션 예시
    sample_sentence = "니" # 사용자님이 제공해주신 데이터셋의 첫 번째 문장
    
    # ONNX가 낮은 확신도를 보였다고 가정
    initial_domain = "일반" 
    initial_confidence = 0.5521
    
    # 페이로드 생성
    api_payload = build_gemini_payload(
        input_sentence=sample_sentence, 
        onnx_initial_domain=initial_domain, 
        onnx_initial_conf=initial_confidence
    )
    
    print("="*50)
    print(" LLM API 호출 시뮬레이션 페이로드 (ONNX 확신도 낮음) ")
    print("="*50)
    # 실제 API 호출 시에는 이 딕셔너리를 JSON 문자열로 변환하여 POST 요청을 보냅니다.
    print(json.dumps(api_payload, indent=4, ensure_ascii=False))

    print("\n\n--- 예상되는 LLM JSON 응답 구조 ---")
    print(json.dumps(RESPONSE_SCHEMA, indent=4, ensure_ascii=False))