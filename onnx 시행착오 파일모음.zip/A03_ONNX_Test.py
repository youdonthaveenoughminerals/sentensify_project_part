import onnxruntime
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from skl2onnx.common.data_types import FloatTensorType

# ***************************************************************
# '02_Model_Training_Fix.py' 파일에서 사용된 데이터셋 생성 로직 재사용
# ***************************************************************

def prepare_data():
    """모델 학습에 사용된 가상의 데이터를 동일하게 생성하고 분리합니다."""
    data_size = 500
    np.random.seed(42)
    data = pd.DataFrame({
        'feature_1': np.random.randint(20, 200, size=data_size),
        'feature_2': np.random.randint(0, 2, size=data_size),
        'feature_3': np.random.rand(data_size).round(1),
        'target_category': np.random.choice(['A', 'B', 'C', 'D'], size=data_size)
    })
    le = LabelEncoder()
    data['target_label'] = le.fit_transform(data['target_category'])
    X = data[['feature_1', 'feature_2', 'feature_3']]
    y = data['target_label']
    X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # ONNX Runtime은 float32 입력을 요구하는 경우가 많으므로 변환합니다.
    return X_test.values.astype(np.float32)

def load_and_test_onnx_model(onnx_path, X_test_data):
    """ONNX Runtime을 사용하여 모델을 로드하고 예측을 수행합니다."""
    print(f"\n--- ONNX Runtime 테스트 시작 ({onnx_path}) ---")
    
    try:
        session = onnxruntime.InferenceSession(onnx_path, providers=['CPUExecutionProvider'])
        input_name = session.get_inputs()[0].name 
        onnx_results = session.run(None, {input_name: X_test_data})
        
        onnx_label_preds = onnx_results[0]
        raw_onnx_proba_preds = onnx_results[1] # 원본 확률 결과 (List of Dicts)
        
        print("✅ ONNX Runtime 추론 성공.")
        
        # ***************************************************************
        # 🚨 확률 결과 클렌징 로직 추가 🚨
        # List of Dicts 형태를 2차원 Numpy 배열로 변환합니다.
        # 각 딕셔너리 키(클래스 ID) 순서대로 확률 값을 추출합니다.
        # ***************************************************************
        if isinstance(raw_onnx_proba_preds, list) and isinstance(raw_onnx_proba_preds[0], dict):
            # 딕셔너리에서 키를 정렬된 리스트로 가져와야 합니다. (e.g., [0, 1, 2, 3])
            class_ids = sorted(raw_onnx_proba_preds[0].keys())
            
            # 각 샘플에서 정렬된 클래스 ID 순서대로 확률 값만 추출하여 리스트에 저장
            cleaned_probas = []
            for item in raw_onnx_proba_preds:
                # 딕셔너리에서 값(확률)만 추출하여 리스트에 추가
                probas = [item[cid] for cid in class_ids]
                cleaned_probas.append(probas)
            
            # 최종적으로 Numpy 배열로 변환합니다.
            onnx_proba_preds = np.array(cleaned_probas, dtype=np.float32)
            print("✅ 확률 결과, List of Dicts에서 Numpy 배열로 클렌징 완료.")
        
        elif isinstance(raw_onnx_proba_preds, np.ndarray):
            # 이미 Numpy 배열인 경우 그대로 사용
            onnx_proba_preds = raw_onnx_proba_preds
        else:
            # 예상치 못한 경우
            print(f"❌ 확률 결과가 예상치 못한 타입입니다: {type(raw_onnx_proba_preds)}")
            return

        # 결과 요약 (클렌징 후)
        print(f"  > 예측된 레이블 타입: {type(onnx_label_preds)}")
        print(f"  > 예측된 레이블 크기: {onnx_label_preds.shape}")
        print(f"  > 예측된 확률 타입 (클렌징 후): {type(onnx_proba_preds)}")
        print(f"  > 예측된 확률(클래스 점수) 크기 (클렌징 후): {onnx_proba_preds.shape}")
        
        # 첫 5개 샘플의 예측 결과 출력
        print("\n--- 첫 5개 샘플 예측 결과 ---")
        for i in range(5):
             # 이제 확률 결과가 2차원 Numpy 배열이므로 접근이 단순해집니다.
             label = onnx_label_preds[i]
             proba = onnx_proba_preds[i] # 전체 클래스에 대한 확률
             
             # 가장 높은 확률을 가진 클래스를 찾습니다.
             predicted_class = np.argmax(proba) 
             
             # 예측된 레이블과 argmax로 찾은 클래스가 일치하는지 확인합니다.
             match_status = "일치" if label == predicted_class else "불일치 (오류 가능성)"
             
             print(f"샘플 {i}: 레이블 {label} ({match_status}), 확률 {proba}")

        print(f"\nONNX 출력 데이터 타입: {onnx_proba_preds.dtype}")


    except Exception as e:
        print(f"❌ ONNX 모델 로드 또는 추론 중 오류 발생: {e}")
        return

if __name__ == "__main__":
    MODEL_PATH = "lgbm_model.multiclass.onnx"
    
    # 1. 테스트 데이터 준비 (학습 데이터와 동일한 형태로)
    X_test_for_onnx = prepare_data()
    
    # 2. ONNX 모델 테스트 실행
    load_and_test_onnx_model(MODEL_PATH, X_test_for_onnx)
    
    print("\n--- ONNX Runtime 테스트 완료 ---")