import pandas as pd
import numpy as np
import lightgbm as lgb
import os
import sys

# ONNX 변환 라이브러리 로드
try:
    # NumPy, ONNX 버전 충돌 해결 후, LightGBM 변환기 등록을 위한 핵심 모듈 임포트
    from skl2onnx import convert_sklearn, initial_types
    from skl2onnx.common.data_types import FloatTensorType
    # LightGBM to ONNX 변환을 위해 LightGBM 자체에서 제공하는 등록 함수 임포트
    # 이 함수가 'Shape Calculator' 누락 오류를 해결하는 핵심입니다.
    from lightgbm.onnx import register_converter as register_lightgbm_converter
    
    # LightGBM 모델을 skl2onnx에 등록
    register_lightgbm_converter()
    print("✅ ONNX/Scikit-learn 핵심 변환 라이브러리 로드 성공. (클린 설치 환경 적용)")
except ImportError as e:
    print(f"❌ ONNX/Scikit-learn 핵심 변환 라이브러리 로드 실패: {e}")
    print(" -> 'pip install skl2onnx onnxruntime lightgbm' 명령을 확인해주세요.")
    sys.exit(1)

print("\n--- LightGBM to ONNX 최종 파이프라인 시작 (클린 환경 재시도) ---")

def run_onnx_pipeline(file_path="test_data.csv", onnx_output_path="lightgbm_model_final.onnx"):
    try:
        # 1. 학습 데이터 로드 및 가상 특성 생성
        print(f"1. 학습 데이터 로드 및 가상 특성 생성 시작: '{file_path}'")
        df = pd.read_csv(file_path)
        
        # 텍스트 데이터에서 LightGBM이 사용할 수 있는 가상 특성(피처) 생성
        # 실제 프로젝트에서는 형태소 분석, N-gram, TF-IDF 등을 사용해야 합니다.
        df['text_length'] = df['content'].apply(len)
        df['word_count'] = df['content'].apply(lambda x: len(x.split()))
        df['has_comma'] = df['content'].apply(lambda x: 1 if ',' in x else 0)
        df['field_news'] = df['field'].apply(lambda x: 1 if x == '기사' else 0)
        df['field_report'] = df['field'].apply(lambda x: 1 if x == '보고서' else 0)
        
        # 'field'를 예측하는 분류 문제로 가정하고, target을 numerical로 인코딩
        target_map = {name: i for i, name in enumerate(df['field'].unique())}
        df['target'] = df['field'].map(target_map)
        
        # 특성(X)과 타겟(Y) 정의
        features = ['text_length', 'word_count', 'has_comma', 'field_news', 'field_report']
        X = df[features].values
        Y = df['target'].values
        
        print(f"    -> 특성 개수: {X.shape[1]}개, 학습 데이터 크기: {X.shape[0]}개")

        # 2. LightGBM 모델 학습
        print("2. LightGBM 모델 학습 시작...")
        model = lgb.LGBMClassifier(objective='multiclass', num_class=len(target_map), random_state=42)
        model.fit(X, Y)
        print("    -> LightGBM 모델 학습 완료.")

        # 3. LightGBM 모델 ONNX 변환
        print(f"3. LightGBM 모델 ONNX 변환 시작: '{onnx_output_path}'")
        
        # skl2onnx에 입력 형태(Input Type) 명시 (필수!)
        # [None, X.shape[1]] = [샘플 수(가변), 피처 개수(5개)]
        initial_type = [('float_input', FloatTensorType([None, X.shape[1]]))]

        onx = convert_sklearn(
            model, 
            initial_types=initial_type,
            target_opset=13  # ONNX Opset 버전을 명시 (일반적으로 13 또는 17 사용)
        )

        # ONNX 파일 저장
        with open(onnx_output_path, "wb") as f:
            f.write(onx.SerializeToString())

        print(f"✅ ONNX 변환 성공: '{onnx_output_path}' 파일이 생성되었습니다.")

    except Exception as e:
        print(f"❌ ONNX 변환 실패 (클린 환경 재시도): {e}")

    finally:
        print("\n--- LightGBM to ONNX 최종 파이프라인 완료 ---")


if __name__ == '__main__':
    run_onnx_pipeline()