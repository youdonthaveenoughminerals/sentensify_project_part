import time
import random
import json

# --- 1. 환경 설정 및 상수 ---
# Klue-BERT 대신 사용할 ONNX 최적화 모델의 예상 성능 (목표치)
ONNX_INFERENCE_TIME_MS = 3 
# ONNX 모델이 확신하지 못하여 Gemini를 호출할 임계값
CONFIDENCE_THRESHOLD = 0.85 

# 시뮬레이션을 위한 Mock API Key (실제 환경에서는 __api_key__ 변수 사용)
API_KEY = ""
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key={API_KEY}"

# --- 2. Mock 함수 정의 ---

def run_onnx_inference(text):
    """
    ONNX 최적화 모델의 빠른 추론을 시뮬레이션합니다.
    """
    # 속도 시뮬레이션
    time.sleep(ONNX_INFERENCE_TIME_MS / 1000)
    
    # 텍스트 길이에 따른 가상의 교정/확신도 생성
    text_length = len(text)
    
    # 팀원 B의 문제점 시뮬레이션: 복잡한 문장(긴 문장)에서 확신도가 낮아짐
    confidence = 0.95 - (min(text_length, 200) / 400) * 0.2  # 최대 0.75까지 낮아질 수 있음
    
    # 만약 확신도가 0.85 미만이면, ONNX의 교정 결과는 '실패'했다고 가정
    if confidence < CONFIDENCE_THRESHOLD:
        corrected_text = f"ONNX 1차 교정 실패 (확신도 {confidence:.4f})"
        return corrected_text, confidence
        
    return f"ONNX 1차 교정 완료: {text[:20]}...", confidence

async def call_gemini_for_deep_correction(original_text, user_context_data):
    """
    Gemini API를 호출하여 맥락 기반 교정 및 개인화를 수행합니다.
    """
    print(f"\n[GEMINI 호출] ONNX 확신도 낮음({original_text[:15]}...) -> 2차 심층 교정 시작.")

    # --- 핵심 프롬프트 설계: 맥락 이해 및 개인화 강제 ---
    system_prompt = f"""
    당신은 Sentensify의 고급 문장 완성 및 교정 시스템입니다. 
    1. 사용자의 과거 데이터({json.dumps(user_context_data, ensure_ascii=False)})를 분석하여 사용자의 도메인(예: 마케팅, 논문)과 선호하는 어조(Tone)를 파악하세요.
    2. 사용자 문장을 문법적 오류를 넘어, 맥락적으로 가장 자연스럽고 설득력 있게 완성/교정하세요.
    3. 사용자 데이터에 기반하여, 원문보다 더 나은 '고급 문장' 하나만 반환하세요.
    4. 당신의 최종 확신도(Confidence Score)는 0.95 이상이어야 합니다.
    """
    user_query = f"다음 문장을 교정 및 완성하세요: '{original_text}'"

    payload = {
        "contents": [{"parts": [{"text": user_query}]}],
        "systemInstruction": {"parts": [{"text": system_prompt}]},
    }
    
    # Fetch API 호출 시뮬레이션 (실제 API 호출 코드는 런타임 환경에 따라 달라질 수 있습니다.)
    # 여기서는 시간만 시뮬레이션합니다.
    start_time = time.time()
    # Gemini API 호출 시간 (네트워크 지연 포함) 시뮬레이션: 200~500ms
    simulated_delay = random.uniform(0.2, 0.5) 
    time.sleep(simulated_delay)
    
    # Mock 응답
    mock_gemini_correction = f"Gemini 교정: {original_text[:15]}... 문장이 사용자의 {user_context_data.get('domain', '일반')} 맥락에 맞게 고급화되었습니다."
    
    end_time = time.time()
    
    print(f"  [GEMINI 완료] 소요 시간: {(end_time - start_time) * 1000:.2f}ms")
    return mock_gemini_correction


# --- 3. 통합 실행 로직 (Hybrid Controller) ---

async def hybrid_correction_controller(text, user_data):
    """
    ONNX를 기본으로 실행하고, 확신도에 따라 Gemini를 호출하는 핵심 로직
    """
    
    # 1. ONNX (1차 고속 추론) 실행
    onnx_start = time.time()
    onnx_result, onnx_confidence = run_onnx_inference(text)
    onnx_elapsed = (time.time() - onnx_start) * 1000
    
    print("-" * 50)
    print(f"1차 ONNX 결과 | 확신도: {onnx_confidence:.4f} | 시간: {onnx_elapsed:.2f}ms")

    # 2. 확신도 기반 Gemini 개입 결정 (Speed vs. Accuracy Trade-off)
    if onnx_confidence < CONFIDENCE_THRESHOLD:
        print(f"[개입 필요] 확신도({onnx_confidence:.4f})가 임계값({CONFIDENCE_THRESHOLD:.2f}) 미만이므로 Gemini를 호출합니다.")
        # 2-1. Gemini (2차 심층 교정) 실행
        gemini_result = await call_gemini_for_deep_correction(text, user_data)
        final_result = gemini_result
        final_model = "Gemini"
        
    else:
        # 2-2. ONNX 결과 채택 (고속 처리)
        final_result = onnx_result
        final_model = "ONNX"

    total_time = (time.time() - onnx_start) * 1000 # ONNX 시작 시점부터 총 소요 시간
    
    print(f"-" * 50)
    print(f"최종 모델: {final_model} | 최종 결과: {final_result}")
    print(f"**총 소요 시간: {total_time:.2f}ms**")
    print("-" * 50)
    return final_result

# --- 4. 실행 시뮬레이션 ---

# 사용자별 개인화 데이터 (Firestore에서 가져온다고 가정)
USER_CONTEXT_DATA = {
    "user_id": "user_12345",
    "domain": "마케팅",
    "recent_topics": ["AI 스타트업 IPO", "클라우드 서비스"],
    "preferred_tone": "전문적, 설득적",
}

# 시뮬레이션 문장 1: 간단하고 명확한 문장 (ONNX로 충분)
EASY_SENTENCE = "오늘 날씨는 매우 맑고 상쾌합니다. 밖에 나가기 좋은 날이네요." 

# 시뮬레이션 문장 2: 길고 복잡하며 맥락이 필요한 문장 (Gemini 개입 필요)
# 팀원 A의 입력(166자)보다 조금 더 긴 문장으로 시뮬레이션
COMPLEX_SENTENCE = """
AI 스타트업 업스테이지가 기업공개(IPO)에 나섰다. 아마존, AMD 등 글로벌 빅테크로부터 투자를 유치하면서 선도적인 기술력을 입증한 만큼 시장의 기대감도 크다. 국내 증시에서도 AI 열풍이 이어지고 있고 최근 상장한 AI 기업도 흥행에 성공한 가운데 업스테이지가 시장에 활기를 더할 전망이다. 이로 인해 한국 기술 시장의 미래에 대한 낙관론이 확산되고 있다.
"""

print("==================================================")
print("       [시뮬레이션 1: ONNX 고속 처리 (Easy)]       ")
print("==================================================")
# NOTE: Jupyter/Async 환경이 아니므로, 동기적으로 호출하도록 수정
# Python 환경에서 비동기 함수를 동기적으로 호출하는 경우:
import asyncio

async def main():
    print(f"\n[입력 문장 1]: {EASY_SENTENCE}")
    await hybrid_correction_controller(EASY_SENTENCE, USER_CONTEXT_DATA)

    print("\n\n==================================================")
    print("      [시뮬레이션 2: Gemini 개입 처리 (Complex)]      ")
    print("==================================================")
    print(f"\n[입력 문장 2]: {COMPLEX_SENTENCE[:40]}...")
    await hybrid_correction_controller(COMPLEX_SENTENCE, USER_CONTEXT_DATA)

if __name__ == "__main__":
    # Python 3.7+ 환경에서 동기 실행을 위해 asyncio.run 사용
    try:
        asyncio.run(main())
    except RuntimeError as e:
        # Windows 환경에서 Runtime Error 방지
        if "cannot run" in str(e):
             loop = asyncio.get_event_loop()
             loop.run_until_complete(main())
        else:
            raise e